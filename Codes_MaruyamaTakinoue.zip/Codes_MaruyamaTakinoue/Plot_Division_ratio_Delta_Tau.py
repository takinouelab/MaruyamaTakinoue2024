import numba
from numba import jit
from PIL import Image
import numpy as np
import glob
from tkinter import filedialog
from tkinter import messagebox
from natsort import natsorted
import matplotlib.pyplot as plt
import os
from datetime import datetime
import shutil
import statistics
import math
import pathlib

#plt.rcParams['font.family'] = "MS Gothic"

idir = '/Users/' ##initial directory

expdir_list = []
num_exp = 1
for i in range(num_exp):
    expdir = filedialog.askdirectory(initialdir = idir) #Please select the result directory
    expdir_list.append(expdir)

dt = 0.1
time_interval = 1000

def Make_Average_array(folder_name):
    component_dir = expdir+"/"+folder_name
    csvlist = natsorted(glob.glob(component_dir+"/*.csv"))
    average_val_array = np.zeros(len(csvlist), dtype = 'float64')
    time_array = np.zeros(len(csvlist), dtype = 'float64')
    for i in range(len(csvlist)):
        csv_array = np.loadtxt(csvlist[i], delimiter=',')
        average_val = np.mean(csv_array)
        average_val_array[i] = average_val
        time_array[i] = i*dt*time_interval
    return average_val_array, time_array

########### Plot of Normalized Divison ratio #################

def make_plot_Div_ratio_non_cleave_normalize(time_array, La_array, imta1_array, imta2_array, Lg_array, imtg1_array, imtg2_array, K1_sq, K2_sq, power):
    Div_ratio_a_array = (K1_sq)**power/((K1_sq)**power+(La_array+imta1_array+imta2_array)**power)
    ini_a = (K1_sq)**power/((K1_sq)**power+1)
    Norm_Div_ratio_a_array = (Div_ratio_a_array - ini_a)/(1-ini_a)
    Div_ratio_g_array = (K2_sq)**power/((K2_sq)**power+(Lg_array+imtg1_array+imtg2_array)**power)
    ini_g = (K2_sq)**power/((K2_sq)**power+1)
    Norm_Div_ratio_g_array = (Div_ratio_g_array - ini_g)/(1-ini_g)
    #time_array = result1[1]
    plt.plot(time_array, Norm_Div_ratio_a_array, marker = "o", markersize=5, markeredgecolor = "blue", linewidth=1, color="blue")  # plot division ratio of B-droplet (r_div_B)
    plt.plot(time_array, Norm_Div_ratio_g_array, marker = "o", markersize=5, markeredgecolor ="red", linewidth=1, color="red")  # plot division ratio of B-droplet (r_div_C)
    plt.xlabel("normalized t (τ)")
    plt.ylabel("Div-ratio")
    plt.ylim(-0.1,1.1)
    plt.title(analysis_method+"\n dt: "+str(dt)+"_stepsize: "+str(time_interval)+"\n K_AB: "+str(K1_sq)+"_K_AC: "+str(K2_sq), fontsize=7)
	#plt.xlim(0,8000)
    plt.savefig(savedir+"/Div-ratio_plot_non-cleave_KAB"+str('{:.2f}'.format(K1_sq))+"_KAC"+str('{:.2f}'.format(K2_sq))+"_n"+str(power)+"_normalize.png", dpi=300)
    plt.close('all')

########### Calculation of delta Tau #################

def Calc_difference_Psrate_non_cleave_normalize(KAB, KAC, power, time_array, La_array, imta1_array, imta2_array, Lg_array, imtg1_array, imtg2_array):
    Psrate_a_array = (KAB)**power/((KAB)**power+(La_array+imta1_array+imta2_array)**power)
    ini_a = (KAB)**power/((KAB)**power+1)
    Norm_Psrate_a_array = (Psrate_a_array - ini_a)/(1-ini_a)
    Psrate_g_array = (KAC)**power/((KAC)**power+(Lg_array+imtg1_array+imtg2_array)**power)
    ini_g = (KAC)**power/((KAC)**power+1)
    Norm_Psrate_g_array = (Psrate_g_array - ini_g)/(1-ini_g)
    for i in range(Norm_Psrate_a_array.shape[0]):
        if Norm_Psrate_a_array[i] >= 0.5:
            time_La = time_array[i]
            break
        else:
            time_La = time_array[i]
    for i in range(Norm_Psrate_g_array.shape[0]):
        if Norm_Psrate_g_array[i] >= 0.5:
            time_Lg = time_array[i]
            break
        else:
            time_Lg = time_array[i]
    difference = time_La -time_Lg
    return difference


for i in range(len(expdir_list)):
    expdir = expdir_list[i]

    now = datetime.now()
    folder_name = now.strftime("%Y-%m-%d-%H-%M-%S")+"_Div-ratio_normalize"
    savedir = expdir+"/"+folder_name 
    if (not os.path.isdir(savedir)):
        os.mkdir(savedir)
    code = os.path.abspath(__file__)
    shutil.copy(code,savedir+"/"+folder_name+"_code.py") 

    time_array = Make_Average_array("La")[1]

    pfa1_array = Make_Average_array("pfa1")[0]
    fa1_array = Make_Average_array("fa1")[0]
    La_array = Make_Average_array("La")[0]
    imta1_array = Make_Average_array("imta1")[0]
    imta2_array = Make_Average_array("imta2")[0]
    cla1_array = Make_Average_array("cla1")[0]
    cla2_array = Make_Average_array("cla2")[0]

    pfg1_array = Make_Average_array("pfg1")[0]
    fg1_array = Make_Average_array("fg1")[0]
    Lg_array = Make_Average_array("Lg")[0]
    imtg1_array = Make_Average_array("imtg1")[0]
    imtg2_array = Make_Average_array("imtg2")[0]
    clg1_array = Make_Average_array("clg1")[0]
    clg2_array = Make_Average_array("clg2")[0]

    p_expdir = pathlib.Path(expdir)

    analysis_method = p_expdir.name[20:]

    KAB, KAC, n = 0.10, 0.90, 16

    make_plot_Div_ratio_non_cleave_normalize(time_array, La_array, imta1_array, imta2_array, Lg_array, imtg1_array, imtg2_array, KAB, KAC, n)
    delta_Tau = Calc_difference_Psrate_non_cleave_normalize(KAB, KAC, n, time_array, La_array, imta1_array, imta2_array, Lg_array, imtg1_array, imtg2_array)
    print(delta_Tau)

    print("Done")