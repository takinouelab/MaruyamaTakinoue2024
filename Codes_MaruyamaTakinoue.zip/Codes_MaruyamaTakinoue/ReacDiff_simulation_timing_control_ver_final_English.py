import numba
from numba import jit
from PIL import Image
import numpy as np
import glob
from tkinter import filedialog
from tkinter import messagebox
from natsort import natsorted
import matplotlib.pyplot as plt
import os
from datetime import datetime
import shutil
import statistics
import math
import pathlib




############ Parameters ###############
L = 100
cen = L//2 #Position of the centre
d = 30 #radius of droplet
dt = 0.03

kappa_in = 0.34 #Normalised diffusion coefficient in droplet
kappa_out = 6 #Normalised diffusion coefficient outside droplet

kh1 = 1 #Normalized hybridization constant between Trigger and RNA 
kh1_l = 1 #Normalized hybridization constant between Trigger and Linker_daggar_AB (delayed linker) 
kcat1 = 0.0199 #Normalized kcat
ksd1 = 0.6 #Normalized strand displacement constant

kh2 = 1 #Normalized hybridization constant between Trigger and LinkerAB (non-delayed linker) 
kcat2 = 0.0199 #Normalized kcat
ksd2 = 0.6 #Normalized strand displacement constant

km = 0.945 #Normalized Km 

condition_index = int(input("condition. 1: 1.5x_0.0125U, 2: 1.5x_0.025U, 3: 1.5x_0.05U, 4: 1.0x_0.025U, 5: 2.0x_0.025U. Please input one of 1-5:  "))

list_RNAconc = [0, 0.152, 0.303] #1.0x, 1.5x, 2.0x
list_RNaseH_conc = [0.0103, 0.0206, 0.0412] #0.0125 U/uL, 0.025 U/uL, 0.05 U/uL

if condition_index == 1:
    u_r1_0, u_r2_0, en_all = 0.152, 0.152, 0.0103  #1.5x_0.0125U # initial concentration of Inhibitor RNA and RNase H
    RNA_conc, RNaseH_conc = "1.5x", "0.0125x"
elif condition_index == 2:
    u_r1_0, u_r2_0, en_all = 0.152, 0.152, 0.0206  #1.5x_0.025U # initial concentration of Inhibitor RNA and RNase H
    RNA_conc, RNaseH_conc = "1.5x", "0.025x"
elif condition_index == 3:
    u_r1_0, u_r2_0, en_all = 0.152, 0.152, 0.0412  #1.5x_0.05U # initial concentration of Inhibitor RNA and RNase H
    RNA_conc, RNaseH_conc = "1.5x", "0.05x"
elif condition_index == 4:
    u_r1_0, u_r2_0, en_all = 0, 0, 0.0206  #1.0x_0.025U # initial concentration of Inhibitor RNA and RNase H
    RNA_conc, RNaseH_conc = "1.0x", "0.025x"
elif condition_index == 5:
    u_r1_0, u_r2_0, en_all = 0.303, 0.303, 0.0206  #2.0x_0.025U # initial concentration of Inhibitor RNA and RNase H
    RNA_conc, RNaseH_conc = "2.0x", "0.025x"
elif condition_index == 6:
    u_r1_0, u_r2_0, en_all = 0, 0, 0.0206  #0x_0.025U # initial concentration of Inhibitor RNA and RNase H
    RNA_conc, RNaseH_conc = "0x", "0.025x"

u_pf1_0, u_pf2_0, u_l_0, u_f1_0, u_f2_0 = 0.303, 0.303, 0.1, 0, 0 
#For delyed-Linker. initial concentration for Inhibited-Triggers (u_pf1_0 and u_pf2_0), delayed-Linker (u_l_0), and Active Triggers (u_f1_0 and u_f2_0)

v_pf1_0, v_pf2_0, v_r1_0, v_r2_0, v_l_0, v_f1_0, v_f2_0 = 0, 0, 0, 0, 0.9, 3.03, 3.03
#For non-delyed-Linker. initial concentration for Inhibited-Triggers (u_pf1_0 and u_pf2_0), Inhibitor RNA (v_r1_0, v_r2_0), delayed-Linker (u_l_0), and Active Triggers (u_f1_0 and u_f2_0)

en = en_all

step = 0 #step number
a_row = np.zeros((L, 2)) #Array storing the index of the Linker's boundary position.
a_col = np.zeros((L, 2))



now = datetime.now()
folder_name = now.strftime("%Y-%m-%d-%H-%M-%S_Di"+str(kappa_in)+"_Do"+str(kappa_out)+"_dt"+str(dt)+"_RNA"+str(RNA_conc)+"_RNaseH"+str(RNaseH_conc))
current = os.path.dirname(os.path.abspath(__file__))
current_p = pathlib.Path(current)
parent_folder = str(current_p.parent)
savedir = parent_folder+"/"+folder_name
if (not os.path.isdir(savedir)):
    os.mkdir(savedir)
code = os.path.abspath(__file__)
shutil.copy(code, savedir+"/"+folder_name+"_code.py")



########### Calcuration of diffusion term ##############

@jit    
def Calc_Linker_boundry_side(L_ini): 
    list_left = [] 
    list_right = []
    list_top = []
    list_bottom = []
    for xi in range(1,L-1):
        for yi in range(1,L-1):
            if L_ini[xi, yi] == 0:
                if L_ini[xi-1, yi] > 0:
                    list_left.append([xi,yi])
                if L_ini[xi+1, yi] > 0:
                    list_right.append([xi,yi])
                if L_ini[xi, yi-1] > 0:
                    list_bottom.append([xi,yi])            
                if L_ini[xi, yi+1] > 0:
                    list_top.append([xi,yi])
    array_left = np.array(list_left)
    array_right = np.array(list_right)
    array_top = np.array(list_top)
    array_bottom = np.array(list_bottom)
    return array_left, array_right, array_top, array_bottom


@jit
def Calc_diffusion_edge(xi, yi, s): #Calculation of diffusion term at edge
    dh = 1
    if xi == 0 and yi != 0 and yi != L-1:
        lps = (s[xi+1, yi]+s[L-1, yi]+s[xi, yi+1]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0)
    elif xi == L-1 and yi != 0 and yi != L-1:
        lps = (s[0, yi]+s[xi-1, yi]+s[xi, yi+1]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0)
    elif yi == 0 and xi != 0 and xi != L-1:
        lps = (s[xi+1, yi]+s[xi-1, yi]+s[xi, yi+1]+s[xi, L-1]-4.0*s[xi, yi])/(dh**2.0)
    elif yi == L-1 and xi != 0 and xi != L-1:
        lps = (s[xi+1, yi]+s[xi-1, yi]+s[xi, 0]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0)

    elif xi == 0 and yi == 0:
        lps = (s[xi+1, yi]+s[L-1, yi]+s[xi, yi+1]+s[xi, L-1]-4.0*s[xi, yi])/(dh**2.0)
    elif xi == L-1 and yi == 0:
        lps = (s[0, yi]+s[xi-1, yi]+s[xi, yi+1]+s[xi, L-1]-4.0*s[xi, yi])/(dh**2.0)
    elif xi == 0 and yi == L-1:
        lps = (s[xi+1, yi]+s[L-1, yi]+s[xi, 0]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0)
    elif xi == L-1 and yi == L-1:
        lps = (s[0, yi]+s[xi-1, yi]+s[xi, 0]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0)

    diff_term = kappa_out * lps
    return diff_term


@jit
def Calc_diffusion_Fuel(s, L_ini, array_left, array_right, array_top, array_bottom): #Calculation of diffusion term of Trigger
    dh = 1
    lp_s = np.zeros((L, L), dtype = 'float64')

    for xi in range(0, L): 
        for yi in range(0, L):
            if xi == 0 or xi == L-1 or yi == 0 or yi == L-1: 
                diff_term = Calc_diffusion_edge(xi, yi, s)
                lp_s[xi,yi] = diff_term
                #print(diff_term)
            elif L_ini[xi,yi] > 0:
                lps = (s[xi+1, yi]+s[xi-1, yi]+s[xi, yi+1]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0) #In dropelt region, diffusion coefficient is kappa_in
                diff_term = kappa_in*lps
                lp_s[xi,yi] = diff_term
            else:
                lps_pre = (s[xi+1, yi]+s[xi-1, yi]+s[xi, yi+1]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0) #outside dropelt region, diffusion coefficient is kappa_out
                diff_term_pre = kappa_out*lps_pre
                lp_s[xi,yi] = diff_term_pre
    
    for [xi,yi] in array_left:
                lp_s[xi,yi] = lp_s[xi,yi] - (kappa_out * (s[xi-1, yi]-s[xi, yi]))/(dh**2.0) + (kappa_in * (s[xi-1, yi]-s[xi, yi]))/(dh**2.0) #Change the provisionally calculated in- and out-put with the mass on the left-hand side to the value with the correct diffusion coefficient.
    for [xi,yi] in array_right:
                lp_s[xi,yi] = lp_s[xi,yi] - (kappa_out * (s[xi+1, yi]-s[xi, yi]))/(dh**2.0) + (kappa_in * (s[xi+1, yi]-s[xi, yi]))/(dh**2.0)
    for [xi,yi] in array_top:
                lp_s[xi,yi] = lp_s[xi,yi] - (kappa_out * (s[xi, yi+1]-s[xi, yi]))/(dh**2.0) + (kappa_in * (s[xi, yi+1]-s[xi, yi]))/(dh**2.0)               
    for [xi,yi] in array_bottom:
                lp_s[xi,yi] = lp_s[xi,yi] - (kappa_out * (s[xi, yi-1]-s[xi, yi]))/(dh**2.0) + (kappa_in * (s[xi, yi-1]-s[xi, yi]))/(dh**2.0) 

    return lp_s

@jit
def Calc_diffusion_Linker(s, L_ini, array_left, array_right, array_top, array_bottom): #Calculation of diffusion term of Linker
    dh = 1 
    lp_s = np.zeros((L, L), dtype = 'float64')

    for xi in range(0, L):
        for yi in range(0, L):
            if L_ini[xi,yi] > 0:
                lps = (s[xi+1, yi]+s[xi-1, yi]+s[xi, yi+1]+s[xi, yi-1]-4.0*s[xi, yi])/(dh**2.0)
                diff_term = kappa_in*lps
                lp_s[xi,yi] = diff_term
    
    for [xi,yi] in array_left: 
                lp_s[xi-1,yi] = lp_s[xi-1,yi] - (kappa_in * (s[xi, yi]-s[xi-1, yi]))/(dh**2.0) 
    for [xi,yi] in array_right:
                lp_s[xi+1,yi] = lp_s[xi+1,yi] - (kappa_in * (s[xi, yi]-s[xi+1, yi]))/(dh**2.0)
    for [xi,yi] in array_top:
                lp_s[xi,yi+1] = lp_s[xi,yi+1] - (kappa_in * (s[xi, yi]-s[xi, yi+1]))/(dh**2.0)
    for [xi,yi] in array_bottom:
                lp_s[xi,yi-1] = lp_s[xi,yi-1] - (kappa_in * (s[xi, yi]-s[xi, yi-1]))/(dh**2.0)

    return lp_s






@jit
def Linkers_shape(s,a_row,a_col):
    for i in range(L):
        if np.sum(s[i,:])>0:
            tup = np.where(s[i,:]>0)
            index_list = list(tup[0])
            index_min = min(index_list)
            index_max = max(index_list)
            s[i,index_min] = s[i,index_min+1]
            s[i,index_max] = s[i,index_max-1]
            s[i,0:index_min-1] = 0
            s[i,index_max+1:L] = 0
            a_row[i,0] = index_min #Store the value in the array storing the index for the second step onwards
            a_row[i,1] = index_max
        else:
            s[i,:] = 0
            a_row[i,0] = 0
            a_row[i,1] = L-1

        if np.sum(s[:,i])>0:
            tup = np.where(s[:,i]>0)
            index_list = list(tup[0])
            index_min = min(index_list)
            index_max = max(index_list)
            s[index_min,i]=s[index_min+1,i]
            s[index_max,i]=s[index_max-1,i]
            s[0:index_min-1,i] = 0
            s[index_max+1:L,i] = 0
            a_col[i,0] = index_min #Store the value in the array storing the index for the second step onwards
            a_col[i,1] = index_max
        else:
            s[:,i] = 0
            a_col[i,0] = 0
            a_col[i,1] = L-1

@jit
def Linkers_boudary(s,a_row,a_col):
    for i in range(L):
        index_min_row = int(a_row[i,0])
        #print(index_min_row)
        index_max_row = int(a_row[i,1])
        #print(index_max_row)
        s[i,index_min_row] = s[i,index_min_row+1] 
        s[i,index_max_row] = s[i,index_max_row-1]
        if index_min_row > 0:
            s[i,0:index_min_row] = 0
        if index_max_row < L-1:
            s[i,index_max_row+1:L] = 0
        if index_min_row == 0 and index_max_row == L-1:
            s[i,:] = 0

        index_min_col = int(a_col[i,0])
        index_max_col = int(a_col[i,1])
        s[index_min_col,i] = s[index_min_col+1,i]
        s[index_max_col,i] = s[index_max_col-1,i]
        if index_min_col > 0:
            s[0:index_min_col,i] = 0
        if index_max_col < L-1:
            s[index_max_col+1:L,i] = 0
        if index_min_col == 0 and index_max_col == L-1:
            s[:,i] = 0
    

def Initial_conc_Linker(s,ini_val):
    num_exist = 0
    for i in range (d):
        dist = math.floor(math.sqrt(d**2-i**2)) 
        s[cen+i,cen-dist:cen+dist] = ini_val
        s[cen-i,cen-dist:cen+dist] = ini_val
        s[cen-1+i,cen-dist:cen+dist] = ini_val 
        s[cen-1-i,cen-dist:cen+dist] = ini_val
        s[cen-dist:cen+dist,cen+i] = ini_val
        s[cen-dist:cen+dist,cen-i] = ini_val
        s[cen-dist:cen+dist,cen-1+i] = ini_val
        s[cen-dist:cen+dist,cen-1-i] = ini_val
    num_exist = np.count_nonzero(s > 0)
    s[:] = s*(L**2)/num_exist
    #print(num_exist)
    #print(s)
    return s


def Initial_conc_Fuel(s,ini_val):
    num_unexist = 0 
    for i in range (d):
        dist = math.floor(math.sqrt(d**2-i**2)) 
        s[cen+i,cen-dist:cen+dist] = -ini_val
        s[cen-i,cen-dist:cen+dist] = -ini_val
        s[cen-1+i,cen-dist:cen+dist] = -ini_val 
        s[cen-1-i,cen-dist:cen+dist] = -ini_val
        s[cen-dist:cen+dist,cen+i] = -ini_val
        s[cen-dist:cen+dist,cen-i] = -ini_val
        s[cen-dist:cen+dist,cen-1+i] = -ini_val
        s[cen-dist:cen+dist,cen-1-i] = -ini_val
    num_unexist = np.count_nonzero(s < 0)
    num_exist =  L**2 - num_unexist
    s[:] = s*(L**2)/num_exist
    s[:] = s + ini_val*(L**2)/num_exist
    return s


def Initial_Diff_const(s,diff_in,diff_out):
    num_exist = 0 
    for i in range (d):
        dist = math.floor(math.sqrt(d**2-i**2)) 
        s[cen+i,cen-dist:cen+dist] = diff_in
        s[cen-i,cen-dist:cen+dist] = diff_in
        s[cen-1+i,cen-dist:cen+dist] = diff_in 
        s[cen-1-i,cen-dist:cen+dist] = diff_in
        s[cen-dist:cen+dist,cen+i] = diff_in
        s[cen-dist:cen+dist,cen-i] = diff_in
        s[cen-dist:cen+dist,cen-1+i] = diff_in
        s[cen-dist:cen+dist,cen-1-i] = diff_in
    for i in range(L):
        for j in range(L):
            if s[i, j] == 0:
                s[i, j] = diff_out

    


########################### Delayed-Linker reaction ################################

@jit
def diff_ru_pf1(u_pf1, u_r1, u_f1):
    val = -(kcat1*en*u_pf1)/(km+u_pf1) + kh1*u_f1*u_r1
    return val

@jit
def diff_ru_pf2(u_pf2, u_r2, u_f2):
    val = -(kcat1*en*u_pf2)/(km+u_pf2) + kh1*u_f2*u_r2
    return val

@jit
def diff_ru_r1(u_r1, u_f1):
    val = -kh1*u_f1*u_r1
    return val

@jit
def diff_ru_r2(u_r2, u_f2):
    val = -kh1*u_f2*u_r2
    return val

@jit
def diff_ru_l(u_l, u_f1, u_f2):
    val = -kh1_l*u_l*u_f1 - kh1_l*u_l*u_f2
    return val

@jit
def diff_ru_f1(u_pf1, u_r1, u_l, u_f1, u_imt2):
    val = (kcat1*en*u_pf1)/(km+u_pf1) - kh1*u_f1*u_r1 - kh1_l*u_l*u_f1 - ksd1*u_imt2*u_f1
    return val

@jit
def diff_ru_f2(u_pf2, u_r2, u_l, u_f2, u_imt1):
    val = (kcat1*en*u_pf2)/(km+u_pf2) - kh1*u_f2*u_r2 - kh1_l*u_l*u_f2 - ksd1*u_imt1*u_f2
    return val

@jit
def diff_ru_imt1(u_l, u_f1, u_f2, u_imt1):
    val = kh1_l*u_l*u_f1 - ksd1*u_imt1*u_f2
    return val

@jit
def diff_ru_imt2(u_l, u_f1, u_f2, u_imt2):
    val = kh1_l*u_l*u_f2 - ksd1*u_imt2*u_f1
    return val

@jit
def diff_ru_cl1(u_f1, u_f2, u_imt1, u_imt2):
    val = ksd1*u_imt1*u_f2 + ksd1*u_imt2*u_f1
    return val

@jit
def diff_ru_cl2(u_f1, u_f2, u_imt1, u_imt2):
    val = ksd1*u_imt1*u_f2 + ksd1*u_imt2*u_f1
    return val


@jit
def Calc_reac_La(u_pf1, u_pf2, u_r1, u_r2, u_l, u_f1, u_f2, u_imt1, u_imt2, u_cl1, u_cl2, ru_pf1, ru_pf2, ru_r1, ru_r2, ru_l, ru_f1, ru_f2, ru_imt1, ru_imt2, ru_cl1, ru_cl2):

    k1_ru_pf1 = diff_ru_pf1(u_pf1, u_r1, u_f1)
    k1_ru_pf2 = diff_ru_pf1(u_pf2, u_r2, u_f2)
    k1_ru_r1 = diff_ru_r1(u_r1, u_f1)
    k1_ru_r2 = diff_ru_r2(u_r2, u_f2)
    k1_ru_l = diff_ru_l(u_l, u_f1, u_f2)
    k1_ru_f1 = diff_ru_f1(u_pf1, u_r1, u_l, u_f1, u_imt2)
    k1_ru_f2 = diff_ru_f2(u_pf2, u_r2, u_l, u_f2, u_imt1)
    k1_ru_imt1 = diff_ru_imt1(u_l, u_f1, u_f2, u_imt1)
    k1_ru_imt2 = diff_ru_imt2(u_l, u_f1, u_f2, u_imt2)
    k1_ru_cl1 = diff_ru_cl1(u_f1, u_f2, u_imt1, u_imt2)
    k1_ru_cl2 = diff_ru_cl2(u_f1, u_f2, u_imt1, u_imt2)

    k2_ru_pf1 = diff_ru_pf1(u_pf1+k1_ru_pf1*(dt/2), u_r1+k1_ru_r1*(dt/2), u_f1+k1_ru_f1*(dt/2))
    k2_ru_pf2 = diff_ru_pf1(u_pf2+k1_ru_pf2*(dt/2), u_r2+k1_ru_r2*(dt/2), u_f2+k1_ru_f2*(dt/2))
    k2_ru_r1 = diff_ru_r1(u_r1+k1_ru_r1*(dt/2), u_f1+k1_ru_f1*(dt/2))
    k2_ru_r2 = diff_ru_r2(u_r2+k1_ru_r2*(dt/2), u_f2+k1_ru_f2*(dt/2))
    k2_ru_l = diff_ru_l(u_l+k1_ru_l*(dt/2), u_f1+k1_ru_f1*(dt/2), u_f2+k1_ru_f2*(dt/2))
    k2_ru_f1 = diff_ru_f1(u_pf1+k1_ru_pf1*(dt/2), u_r1+k1_ru_r1*(dt/2), u_l+k1_ru_l*(dt/2), u_f1+k1_ru_f1*(dt/2), u_imt2+k1_ru_imt2*(dt/2))
    k2_ru_f2 = diff_ru_f2(u_pf2+k1_ru_pf2*(dt/2), u_r2+k1_ru_r2*(dt/2), u_l+k1_ru_l*(dt/2), u_f2+k1_ru_f2*(dt/2), u_imt1+k1_ru_imt1*(dt/2))
    k2_ru_imt1 = diff_ru_imt1(u_l+k1_ru_l*(dt/2), u_f1+k1_ru_f1*(dt/2), u_f2+k1_ru_f2*(dt/2), u_imt1+k1_ru_imt1*(dt/2))
    k2_ru_imt2 = diff_ru_imt2(u_l+k1_ru_l*(dt/2), u_f1+k1_ru_f1*(dt/2), u_f2+k1_ru_f2*(dt/2), u_imt2+k1_ru_imt2*(dt/2))
    k2_ru_cl1 = diff_ru_cl1(u_f1+k1_ru_f1*(dt/2), u_f2+k1_ru_f2*(dt/2), u_imt1+k1_ru_imt1*(dt/2), u_imt2+k1_ru_imt2*(dt/2))
    k2_ru_cl2 = diff_ru_cl2(u_f1+k1_ru_f1*(dt/2), u_f2+k1_ru_f2*(dt/2), u_imt1+k1_ru_imt1*(dt/2), u_imt2+k1_ru_imt2*(dt/2))

    k3_ru_pf1 = diff_ru_pf1(u_pf1+k2_ru_pf1*(dt/2), u_r1+k2_ru_r1*(dt/2), u_f1+k2_ru_f1*(dt/2))
    k3_ru_pf2 = diff_ru_pf1(u_pf2+k2_ru_pf2*(dt/2), u_r2+k2_ru_r2*(dt/2), u_f2+k2_ru_f2*(dt/2))
    k3_ru_r1 = diff_ru_r1(u_r1+k2_ru_r1*(dt/2), u_f1+k2_ru_f1*(dt/2))
    k3_ru_r2 = diff_ru_r2(u_r2+k2_ru_r2*(dt/2), u_f2+k2_ru_f2*(dt/2))
    k3_ru_l = diff_ru_l(u_l+k2_ru_l*(dt/2), u_f1+k2_ru_f1*(dt/2), u_f2+k2_ru_f2*(dt/2))
    k3_ru_f1 = diff_ru_f1(u_pf1+k2_ru_pf1*(dt/2), u_r1+k2_ru_r1*(dt/2), u_l+k2_ru_l*(dt/2), u_f1+k2_ru_f1*(dt/2), u_imt2+k2_ru_imt2*(dt/2))
    k3_ru_f2 = diff_ru_f2(u_pf2+k2_ru_pf2*(dt/2), u_r2+k2_ru_r2*(dt/2), u_l+k2_ru_l*(dt/2), u_f2+k2_ru_f2*(dt/2), u_imt1+k2_ru_imt1*(dt/2))
    k3_ru_imt1 = diff_ru_imt1(u_l+k2_ru_l*(dt/2), u_f1+k2_ru_f1*(dt/2), u_f2+k2_ru_f2*(dt/2), u_imt1+k2_ru_imt1*(dt/2))
    k3_ru_imt2 = diff_ru_imt2(u_l+k2_ru_l*(dt/2), u_f1+k2_ru_f1*(dt/2), u_f2+k2_ru_f2*(dt/2), u_imt2+k2_ru_imt2*(dt/2))
    k3_ru_cl1 = diff_ru_cl1(u_f1+k2_ru_f1*(dt/2), u_f2+k2_ru_f2*(dt/2), u_imt1+k2_ru_imt1*(dt/2), u_imt2+k2_ru_imt2*(dt/2))
    k3_ru_cl2 = diff_ru_cl2(u_f1+k2_ru_f1*(dt/2), u_f2+k2_ru_f2*(dt/2), u_imt1+k2_ru_imt1*(dt/2), u_imt2+k2_ru_imt2*(dt/2))

    k4_ru_pf1 = diff_ru_pf1(u_pf1+k3_ru_pf1*dt, u_r1+k3_ru_r1*dt, u_f1+k3_ru_f1*dt)
    k4_ru_pf2 = diff_ru_pf1(u_pf2+k3_ru_pf2*dt, u_r2+k3_ru_r2*dt, u_f2+k3_ru_f2*dt)
    k4_ru_r1 = diff_ru_r1(u_r1+k3_ru_r1*dt, u_f1+k3_ru_f1*dt)
    k4_ru_r2 = diff_ru_r2(u_r2+k3_ru_r2*dt, u_f2+k3_ru_f2*dt)
    k4_ru_l = diff_ru_l(u_l+k3_ru_l*dt, u_f1+k3_ru_f1*dt, u_f2+k3_ru_f2*dt)
    k4_ru_f1 = diff_ru_f1(u_pf1+k3_ru_pf1*dt, u_r1+k3_ru_r1*dt, u_l+k3_ru_l*dt, u_f1+k3_ru_f1*dt, u_imt2+k3_ru_imt2*dt)
    k4_ru_f2 = diff_ru_f2(u_pf2+k3_ru_pf2*dt, u_r2+k3_ru_r2*dt, u_l+k3_ru_l*dt, u_f2+k3_ru_f2*dt, u_imt1+k3_ru_imt1*dt)
    k4_ru_imt1 = diff_ru_imt1(u_l+k3_ru_l*dt, u_f1+k3_ru_f1*dt, u_f2+k3_ru_f2*dt, u_imt1+k3_ru_imt1*dt)
    k4_ru_imt2 = diff_ru_imt2(u_l+k3_ru_l*dt, u_f1+k3_ru_f1*dt, u_f2+k3_ru_f2*dt, u_imt2+k3_ru_imt2*dt)
    k4_ru_cl1 = diff_ru_cl1(u_f1+k3_ru_f1*dt, u_f2+k3_ru_f2*dt, u_imt1+k3_ru_imt1*dt, u_imt2+k3_ru_imt2*dt)
    k4_ru_cl2 = diff_ru_cl2(u_f1+k3_ru_f1*dt, u_f2+k3_ru_f2*dt, u_imt1+k3_ru_imt1*dt, u_imt2+k3_ru_imt2*dt)

    ru_pf1[:] = (1/6)*dt*(k1_ru_pf1+2*k2_ru_pf1+2*k3_ru_pf1+k4_ru_pf1)
    ru_pf2[:] = (1/6)*dt*(k1_ru_pf2+2*k2_ru_pf2+2*k3_ru_pf2+k4_ru_pf2)
    ru_r1[:] = (1/6)*dt*(k1_ru_r1+2*k2_ru_r1+2*k3_ru_r1+k4_ru_r1)
    ru_r2[:] = (1/6)*dt*(k1_ru_r2+2*k2_ru_r2+2*k3_ru_r2+k4_ru_r2)
    ru_l[:] = (1/6)*dt*(k1_ru_l+2*k2_ru_l+2*k3_ru_l+k4_ru_l)
    ru_f1[:] = (1/6)*dt*(k1_ru_f1+2*k2_ru_f1+2*k3_ru_f1+k4_ru_f1)
    ru_f2[:] = (1/6)*dt*(k1_ru_f2+2*k2_ru_f2+2*k3_ru_f2+k4_ru_f2)
    ru_imt1[:] = (1/6)*dt*(k1_ru_imt1+2*k2_ru_imt1+2*k3_ru_imt1+k4_ru_imt1)
    ru_imt2[:] = (1/6)*dt*(k1_ru_imt2+2*k2_ru_imt2+2*k3_ru_imt2+k4_ru_imt2)
    ru_cl1[:] = (1/6)*dt*(k1_ru_cl1+2*k2_ru_cl1+2*k3_ru_cl1+k4_ru_cl1)
    ru_cl2[:] = (1/6)*dt*(k1_ru_cl2+2*k2_ru_cl2+2*k3_ru_cl2+k4_ru_cl2)


############ Reaction diffusion equation for delayed-Linker ##############
@jit
def Calc_next_La(u_pf1, u_pf2, u_r1, u_r2, u_l, u_f1, u_f2, u_imt1, u_imt2, u_cl1, u_cl2, u2_pf1, u2_pf2, u2_r1, u2_r2, u2_l, u2_f1, u2_f2, u2_imt1, u2_imt2, u2_cl1, u2_cl2, L_ini, array_left, array_right, array_top, array_bottom):
    (L, _) = u_pf1.shape

    lpu_pf1 = np.zeros((L, L), dtype = 'float64') #Stores diffusion values
    lpu_pf2 = np.zeros((L, L), dtype = 'float64')
    lpu_r1 = np.zeros((L, L), dtype = 'float64')
    lpu_r2 = np.zeros((L, L), dtype = 'float64')
    lpu_l = np.zeros((L, L), dtype = 'float64')
    lpu_f1 = np.zeros((L, L), dtype = 'float64')
    lpu_f2 = np.zeros((L, L), dtype = 'float64')
    lpu_imt1 = np.zeros((L, L), dtype = 'float64')
    lpu_imt2 = np.zeros((L, L), dtype = 'float64')
    lpu_cl1 = np.zeros((L, L), dtype = 'float64')
    lpu_cl2 = np.zeros((L, L), dtype = 'float64')

    ru_pf1 = np.zeros((L, L), dtype = 'float64') #Stores the value of the reaction term
    ru_pf2 = np.zeros((L, L), dtype = 'float64')
    ru_r1 = np.zeros((L, L), dtype = 'float64')
    ru_r2 = np.zeros((L, L), dtype = 'float64')
    ru_l = np.zeros((L, L), dtype = 'float64')
    ru_f1 = np.zeros((L, L), dtype = 'float64')
    ru_f2 = np.zeros((L, L), dtype = 'float64')
    ru_imt1 = np.zeros((L, L), dtype = 'float64')
    ru_imt2 = np.zeros((L, L), dtype = 'float64')
    ru_cl1 = np.zeros((L, L), dtype = 'float64')
    ru_cl2 = np.zeros((L, L), dtype = 'float64')
    
    #Calculation of the diffusion term 
    lpu_pf1 = Calc_diffusion_Fuel(u_pf1, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_pf2 = Calc_diffusion_Fuel(u_pf2, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_r1 = Calc_diffusion_Fuel(u_r1, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_r2 = Calc_diffusion_Fuel(u_r2, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_l = Calc_diffusion_Linker(u_l, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_f1 = Calc_diffusion_Fuel(u_f1, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_f2 = Calc_diffusion_Fuel(u_f2, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_imt1 = Calc_diffusion_Linker(u_imt1, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_imt2 = Calc_diffusion_Linker(u_imt2, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_cl1 = Calc_diffusion_Linker(u_cl1, L_ini, array_left, array_right, array_top, array_bottom)
    lpu_cl2 = Calc_diffusion_Linker(u_cl2, L_ini, array_left, array_right, array_top, array_bottom)
    
    #Calculation of reaction terms.
    Calc_reac_La(u_pf1, u_pf2, u_r1, u_r2, u_l, u_f1, u_f2, u_imt1, u_imt2, u_cl1, u_cl2, ru_pf1, ru_pf2, ru_r1, ru_r2, ru_l, ru_f1, ru_f2, ru_imt1, ru_imt2, ru_cl1, ru_cl2)
    
    #Calculate the value of the next step
    u2_pf1[:] = u_pf1 + lpu_pf1*dt + ru_pf1
    u2_pf2[:] = u_pf2 + lpu_pf2*dt + ru_pf2
    u2_r1[:] = u_r1 + lpu_r1*dt + ru_r1
    u2_r2[:] = u_r2 + lpu_r2*dt + ru_r2
    u2_l[:] = u_l + lpu_l*dt + ru_l
    u2_f1[:] = u_f1 + lpu_f1*dt + ru_f1
    u2_f2[:] = u_f2 + lpu_f2*dt + ru_f2
    u2_imt1[:] = u_imt1 + lpu_imt1*dt + ru_imt1
    u2_imt2[:] = u_imt2 + lpu_imt2*dt + ru_imt2
    u2_cl1[:] = u_cl1 + lpu_cl1*dt + ru_cl1
    u2_cl2[:] = u_cl2 + lpu_cl2*dt + ru_cl2

########################### non-Delayed-Linker ################################
  
@jit
def diff_rv_pf1(v_pf1, v_r1, v_f1):
    val = -(kcat2*en*v_pf1)/(km+v_pf1) + kh2*v_f1*v_r1
    return val

@jit
def diff_rv_pf2(v_pf2, v_r2, v_f2):
    val = -(kcat2*en*v_pf2)/(km+v_pf2) + kh2*v_f2*v_r2
    return val

@jit
def diff_rv_r1(v_r1, v_f1):
    val = -kh2*v_f1*v_r1
    return val

@jit
def diff_rv_r2(v_r2, v_f2):
    val = -kh2*v_f2*v_r2
    return val

@jit
def diff_rv_l(v_l, v_f1, v_f2):
    val = -kh2*v_l*v_f1 - kh2*v_l*v_f2
    return val

@jit
def diff_rv_f1(v_pf1, v_r1, v_l, v_f1, v_imt2):
    val = (kcat2*en*v_pf1)/(km+v_pf1) - kh2*v_f1*v_r1 - kh2*v_l*v_f1 - ksd2*v_imt2*v_f1
    return val

@jit
def diff_rv_f2(v_pf2, v_r2, v_l, v_f2, v_imt1):
    val = (kcat2*en*v_pf2)/(km+v_pf2) - kh2*v_f2*v_r2 - kh2*v_l*v_f2 - ksd2*v_imt1*v_f2
    return val

@jit
def diff_rv_imt1(v_l, v_f1, v_f2, v_imt1):
    val = kh2*v_l*v_f1 - ksd2*v_imt1*v_f2
    return val

@jit
def diff_rv_imt2(v_l, v_f1, v_f2, v_imt2):
    val = kh2*v_l*v_f2 - ksd2*v_imt2*v_f1
    return val

@jit
def diff_rv_cl1(v_f1, v_f2, v_imt1, v_imt2):
    val = ksd2*v_imt1*v_f2 + ksd2*v_imt2*v_f1
    return val

@jit
def diff_rv_cl2(v_f1, v_f2, v_imt1, v_imt2):
    val = ksd2*v_imt1*v_f2 + ksd2*v_imt2*v_f1
    return val


@jit
def Calc_reac_Lb(v_pf1, v_pf2, v_r1, v_r2, v_l, v_f1, v_f2, v_imt1, v_imt2, v_cl1, v_cl2, rv_pf1, rv_pf2, rv_r1, rv_r2, rv_l, rv_f1, rv_f2, rv_imt1, rv_imt2, rv_cl1, rv_cl2):

    k1_rv_pf1 = diff_rv_pf1(v_pf1, v_r1, v_f1)
    k1_rv_pf2 = diff_rv_pf1(v_pf2, v_r2, v_f2)
    k1_rv_r1 = diff_rv_r1(v_r1, v_f1)
    k1_rv_r2 = diff_rv_r2(v_r2, v_f2)
    k1_rv_l = diff_rv_l(v_l, v_f1, v_f2)
    k1_rv_f1 = diff_rv_f1(v_pf1, v_r1, v_l, v_f1, v_imt2)
    k1_rv_f2 = diff_rv_f2(v_pf2, v_r2, v_l, v_f2, v_imt1)
    k1_rv_imt1 = diff_rv_imt1(v_l, v_f1, v_f2, v_imt1)
    k1_rv_imt2 = diff_rv_imt2(v_l, v_f1, v_f2, v_imt2)
    k1_rv_cl1 = diff_rv_cl1(v_f1, v_f2, v_imt1, v_imt2)
    k1_rv_cl2 = diff_rv_cl2(v_f1, v_f2, v_imt1, v_imt2)

    k2_rv_pf1 = diff_rv_pf1(v_pf1+k1_rv_pf1*(dt/2), v_r1+k1_rv_r1*(dt/2), v_f1+k1_rv_f1*(dt/2))
    k2_rv_pf2 = diff_rv_pf1(v_pf2+k1_rv_pf2*(dt/2), v_r2+k1_rv_r2*(dt/2), v_f2+k1_rv_f2*(dt/2))
    k2_rv_r1 = diff_rv_r1(v_r1+k1_rv_r1*(dt/2), v_f1+k1_rv_f1*(dt/2))
    k2_rv_r2 = diff_rv_r2(v_r2+k1_rv_r2*(dt/2), v_f2+k1_rv_f2*(dt/2))
    k2_rv_l = diff_rv_l(v_l+k1_rv_l*(dt/2), v_f1+k1_rv_f1*(dt/2), v_f2+k1_rv_f2*(dt/2))
    k2_rv_f1 = diff_rv_f1(v_pf1+k1_rv_pf1*(dt/2), v_r1+k1_rv_r1*(dt/2), v_l+k1_rv_l*(dt/2), v_f1+k1_rv_f1*(dt/2), v_imt2+k1_rv_imt2*(dt/2))
    k2_rv_f2 = diff_rv_f2(v_pf2+k1_rv_pf2*(dt/2), v_r2+k1_rv_r2*(dt/2), v_l+k1_rv_l*(dt/2), v_f2+k1_rv_f2*(dt/2), v_imt1+k1_rv_imt1*(dt/2))
    k2_rv_imt1 = diff_rv_imt1(v_l+k1_rv_l*(dt/2), v_f1+k1_rv_f1*(dt/2), v_f2+k1_rv_f2*(dt/2), v_imt1+k1_rv_imt1*(dt/2))
    k2_rv_imt2 = diff_rv_imt2(v_l+k1_rv_l*(dt/2), v_f1+k1_rv_f1*(dt/2), v_f2+k1_rv_f2*(dt/2), v_imt2+k1_rv_imt2*(dt/2))
    k2_rv_cl1 = diff_rv_cl1(v_f1+k1_rv_f1*(dt/2), v_f2+k1_rv_f2*(dt/2), v_imt1+k1_rv_imt1*(dt/2), v_imt2+k1_rv_imt2*(dt/2))
    k2_rv_cl2 = diff_rv_cl2(v_f1+k1_rv_f1*(dt/2), v_f2+k1_rv_f2*(dt/2), v_imt1+k1_rv_imt1*(dt/2), v_imt2+k1_rv_imt2*(dt/2))

    k3_rv_pf1 = diff_rv_pf1(v_pf1+k2_rv_pf1*(dt/2), v_r1+k2_rv_r1*(dt/2), v_f1+k2_rv_f1*(dt/2))
    k3_rv_pf2 = diff_rv_pf1(v_pf2+k2_rv_pf2*(dt/2), v_r2+k2_rv_r2*(dt/2), v_f2+k2_rv_f2*(dt/2))
    k3_rv_r1 = diff_rv_r1(v_r1+k2_rv_r1*(dt/2), v_f1+k2_rv_f1*(dt/2))
    k3_rv_r2 = diff_rv_r2(v_r2+k2_rv_r2*(dt/2), v_f2+k2_rv_f2*(dt/2))
    k3_rv_l = diff_rv_l(v_l+k2_rv_l*(dt/2), v_f1+k2_rv_f1*(dt/2), v_f2+k2_rv_f2*(dt/2))
    k3_rv_f1 = diff_rv_f1(v_pf1+k2_rv_pf1*(dt/2), v_r1+k2_rv_r1*(dt/2), v_l+k2_rv_l*(dt/2), v_f1+k2_rv_f1*(dt/2), v_imt2+k2_rv_imt2*(dt/2))
    k3_rv_f2 = diff_rv_f2(v_pf2+k2_rv_pf2*(dt/2), v_r2+k2_rv_r2*(dt/2), v_l+k2_rv_l*(dt/2), v_f2+k2_rv_f2*(dt/2), v_imt1+k2_rv_imt1*(dt/2))
    k3_rv_imt1 = diff_rv_imt1(v_l+k2_rv_l*(dt/2), v_f1+k2_rv_f1*(dt/2), v_f2+k2_rv_f2*(dt/2), v_imt1+k2_rv_imt1*(dt/2))
    k3_rv_imt2 = diff_rv_imt2(v_l+k2_rv_l*(dt/2), v_f1+k2_rv_f1*(dt/2), v_f2+k2_rv_f2*(dt/2), v_imt2+k2_rv_imt2*(dt/2))
    k3_rv_cl1 = diff_rv_cl1(v_f1+k2_rv_f1*(dt/2), v_f2+k2_rv_f2*(dt/2), v_imt1+k2_rv_imt1*(dt/2), v_imt2+k2_rv_imt2*(dt/2))
    k3_rv_cl2 = diff_rv_cl2(v_f1+k2_rv_f1*(dt/2), v_f2+k2_rv_f2*(dt/2), v_imt1+k2_rv_imt1*(dt/2), v_imt2+k2_rv_imt2*(dt/2))

    k4_rv_pf1 = diff_rv_pf1(v_pf1+k3_rv_pf1*dt, v_r1+k3_rv_r1*dt, v_f1+k3_rv_f1*dt)
    k4_rv_pf2 = diff_rv_pf1(v_pf2+k3_rv_pf2*dt, v_r2+k3_rv_r2*dt, v_f2+k3_rv_f2*dt)
    k4_rv_r1 = diff_rv_r1(v_r1+k3_rv_r1*dt, v_f1+k3_rv_f1*dt)
    k4_rv_r2 = diff_rv_r2(v_r2+k3_rv_r2*dt, v_f2+k3_rv_f2*dt)
    k4_rv_l = diff_rv_l(v_l+k3_rv_l*dt, v_f1+k3_rv_f1*dt, v_f2+k3_rv_f2*dt)
    k4_rv_f1 = diff_rv_f1(v_pf1+k3_rv_pf1*dt, v_r1+k3_rv_r1*dt, v_l+k3_rv_l*dt, v_f1+k3_rv_f1*dt, v_imt2+k3_rv_imt2*dt)
    k4_rv_f2 = diff_rv_f2(v_pf2+k3_rv_pf2*dt, v_r2+k3_rv_r2*dt, v_l+k3_rv_l*dt, v_f2+k3_rv_f2*dt, v_imt1+k3_rv_imt1*dt)
    k4_rv_imt1 = diff_rv_imt1(v_l+k3_rv_l*dt, v_f1+k3_rv_f1*dt, v_f2+k3_rv_f2*dt, v_imt1+k3_rv_imt1*dt)
    k4_rv_imt2 = diff_rv_imt2(v_l+k3_rv_l*dt, v_f1+k3_rv_f1*dt, v_f2+k3_rv_f2*dt, v_imt2+k3_rv_imt2*dt)
    k4_rv_cl1 = diff_rv_cl1(v_f1+k3_rv_f1*dt, v_f2+k3_rv_f2*dt, v_imt1+k3_rv_imt1*dt, v_imt2+k3_rv_imt2*dt)
    k4_rv_cl2 = diff_rv_cl2(v_f1+k3_rv_f1*dt, v_f2+k3_rv_f2*dt, v_imt1+k3_rv_imt1*dt, v_imt2+k3_rv_imt2*dt)

    rv_pf1[:] = (1/6)*dt*(k1_rv_pf1+2*k2_rv_pf1+2*k3_rv_pf1+k4_rv_pf1)
    rv_pf2[:] = (1/6)*dt*(k1_rv_pf2+2*k2_rv_pf2+2*k3_rv_pf2+k4_rv_pf2)
    rv_r1[:] = (1/6)*dt*(k1_rv_r1+2*k2_rv_r1+2*k3_rv_r1+k4_rv_r1)
    rv_r2[:] = (1/6)*dt*(k1_rv_r2+2*k2_rv_r2+2*k3_rv_r2+k4_rv_r2)
    rv_l[:] = (1/6)*dt*(k1_rv_l+2*k2_rv_l+2*k3_rv_l+k4_rv_l)
    rv_f1[:] = (1/6)*dt*(k1_rv_f1+2*k2_rv_f1+2*k3_rv_f1+k4_rv_f1)
    rv_f2[:] = (1/6)*dt*(k1_rv_f2+2*k2_rv_f2+2*k3_rv_f2+k4_rv_f2)
    rv_imt1[:] = (1/6)*dt*(k1_rv_imt1+2*k2_rv_imt1+2*k3_rv_imt1+k4_rv_imt1)
    rv_imt2[:] = (1/6)*dt*(k1_rv_imt2+2*k2_rv_imt2+2*k3_rv_imt2+k4_rv_imt2)
    rv_cl1[:] = (1/6)*dt*(k1_rv_cl1+2*k2_rv_cl1+2*k3_rv_cl1+k4_rv_cl1)
    rv_cl2[:] = (1/6)*dt*(k1_rv_cl2+2*k2_rv_cl2+2*k3_rv_cl2+k4_rv_cl2)


############ Reaction diffusion equation for non-delayed-Linker ##############
@jit
def Calc_next_Lb(v_pf1, v_pf2, v_r1, v_r2, v_l, v_f1, v_f2, v_imt1, v_imt2, v_cl1, v_cl2, v2_pf1, v2_pf2, v2_r1, v2_r2, v2_l, v2_f1, v2_f2, v2_imt1, v2_imt2, v2_cl1, v2_cl2, L_ini, array_left, array_right, array_top, array_bottom):
    (L, _) = v_pf1.shape

    lpv_pf1 = np.zeros((L, L), dtype = 'float64') 
    lpv_pf2 = np.zeros((L, L), dtype = 'float64')
    lpv_r1 = np.zeros((L, L), dtype = 'float64')
    lpv_r2 = np.zeros((L, L), dtype = 'float64')
    lpv_l = np.zeros((L, L), dtype = 'float64')
    lpv_f1 = np.zeros((L, L), dtype = 'float64')
    lpv_f2 = np.zeros((L, L), dtype = 'float64')
    lpv_imt1 = np.zeros((L, L), dtype = 'float64')
    lpv_imt2 = np.zeros((L, L), dtype = 'float64')
    lpv_cl1 = np.zeros((L, L), dtype = 'float64')
    lpv_cl2 = np.zeros((L, L), dtype = 'float64')

    rv_pf1 = np.zeros((L, L), dtype = 'float64') 
    rv_pf2 = np.zeros((L, L), dtype = 'float64')
    rv_r1 = np.zeros((L, L), dtype = 'float64')
    rv_r2 = np.zeros((L, L), dtype = 'float64')
    rv_l = np.zeros((L, L), dtype = 'float64')
    rv_f1 = np.zeros((L, L), dtype = 'float64')
    rv_f2 = np.zeros((L, L), dtype = 'float64')
    rv_imt1 = np.zeros((L, L), dtype = 'float64')
    rv_imt2 = np.zeros((L, L), dtype = 'float64')
    rv_cl1 = np.zeros((L, L), dtype = 'float64')
    rv_cl2 = np.zeros((L, L), dtype = 'float64')
    

    lpv_pf1 = Calc_diffusion_Fuel(v_pf1, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_pf2 = Calc_diffusion_Fuel(v_pf2, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_r1 = Calc_diffusion_Fuel(v_r1, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_r2 = Calc_diffusion_Fuel(v_r2, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_l = Calc_diffusion_Linker(v_l, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_f1 = Calc_diffusion_Fuel(v_f1, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_f2 = Calc_diffusion_Fuel(v_f2, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_imt1 = Calc_diffusion_Linker(v_imt1, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_imt2 = Calc_diffusion_Linker(v_imt2, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_cl1 = Calc_diffusion_Linker(v_cl1, L_ini, array_left, array_right, array_top, array_bottom)
    lpv_cl2 = Calc_diffusion_Linker(v_cl2, L_ini, array_left, array_right, array_top, array_bottom)
    
    
    Calc_reac_Lb(v_pf1, v_pf2, v_r1, v_r2, v_l, v_f1, v_f2, v_imt1, v_imt2, v_cl1, v_cl2, rv_pf1, rv_pf2, rv_r1, rv_r2, rv_l, rv_f1, rv_f2, rv_imt1, rv_imt2, rv_cl1, rv_cl2)
    
    
    v2_pf1[:] = v_pf1 + lpv_pf1*dt + rv_pf1
    v2_pf2[:] = v_pf2 + lpv_pf2*dt + rv_pf2
    v2_r1[:] = v_r1 + lpv_r1*dt + rv_r1
    v2_r2[:] = v_r2 + lpv_r2*dt + rv_r2
    v2_l[:] = v_l + lpv_l*dt + rv_l
    v2_f1[:] = v_f1 + lpv_f1*dt + rv_f1
    v2_f2[:] = v_f2 + lpv_f2*dt + rv_f2
    v2_imt1[:] = v_imt1 + lpv_imt1*dt + rv_imt1
    v2_imt2[:] = v_imt2 + lpv_imt2*dt + rv_imt2
    v2_cl1[:] = v_cl1 + lpv_cl1*dt + rv_cl1
    v2_cl2[:] = v_cl2 + lpv_cl2*dt + rv_cl2

################################# save function ###############################

#save png file
def save_file(s,n,array_name,min_val,max_val):
    name = str(array_name)    
    filename = "gs_"+name+"_{:02d}.png".format(n//100)
    #print(filename)
    component_dir = savedir+"/"+name
    if (not os.path.isdir(component_dir)):
        os.mkdir(component_dir)
    plt.imshow(s, cmap="jet",vmin=min_val,vmax=max_val)
    plt.colorbar(orientation='vertical')
    plt.savefig(component_dir+"/"+filename)
    plt.close('all')
    np.savetxt(component_dir+"/gs_"+name+"_{:02d}.csv".format(n//100), s, delimiter=',') ##to three decimal places



#save csv file
def save_csvfile(s,n,array_name):
    name = str(array_name)    
    component_dir = savedir+"/"+name
    if (not os.path.isdir(component_dir)):
        os.mkdir(component_dir)
    np.savetxt(component_dir+"/gs_"+name+"_{:02d}.csv".format(n//500), s, delimiter=',') 


#Function to generate and save images from csv.
def save_imgfile(array_name):
    name = str(array_name)
    component_dir = savedir+"/"+name
    csvlist = natsorted(glob.glob(component_dir+"/*.csv"))
    max_val = 0
    for i in range(len(csvlist)):
        csv_array = np.loadtxt(csvlist[i], delimiter=',')
        if (np.amax(csv_array) >= max_val):
            max_val = np.amax(csv_array)
    for i in range(len(csvlist)):
        csv_array = np.loadtxt(csvlist[i], delimiter=',')
        filename = "gs_"+name+"_{:02d}.png".format(i)
        plt.imshow(csv_array, cmap="jet",vmin=0,vmax=max_val)
        plt.colorbar(orientation='vertical')
        plt.savefig(component_dir+"/"+filename)
        plt.close('all')
    print(name+"_image_Done")


#Function to plot concentrations (plot sum of concentrations)
def make_plot(folder_name,dt,place,fig):
    name = str(folder_name)
    component_dir = savedir+"/"+name
    csvlist = natsorted(glob.glob(component_dir+"/*.csv"))
    total_val_array = np.zeros(len(csvlist), dtype = 'float64')
    time_array = np.zeros(len(csvlist), dtype = 'float64')
    for i in range(len(csvlist)):
        csv_array = np.loadtxt(csvlist[i], delimiter=',')
        total_val = np.sum(csv_array)
        total_val_array[i] = total_val
        time_array[i] = i*dt
    max_val = np.amax(total_val_array)
    ax = fig.add_subplot(3, 4, place)
    labelname = str(folder_name)
    ax.plot(time_array, total_val_array, label=labelname)
    ax.legend(loc = "upper right")
    plt.ylim(0,max_val)
    print("Done")

#Function to plot concentration (plot average of concentration)
def make_plot_ave(folder_name,dt,place,fig):
    name = str(folder_name)
    component_dir = savedir+"/"+name
    csvlist = natsorted(glob.glob(component_dir+"/*.csv"))
    average_val_array = np.zeros(len(csvlist), dtype = 'float64')
    time_array = np.zeros(len(csvlist), dtype = 'float64')
    for i in range(len(csvlist)):
        csv_array = np.loadtxt(csvlist[i], delimiter=',')
        average_val = np.mean(csv_array)
        average_val_array[i] = average_val
        time_array[i] = i*dt
    max_val = np.amax(average_val_array)
    ax = fig.add_subplot(2, 6, place)
    labelname = str(folder_name)
    ax.plot(time_array, average_val_array, label=labelname)
    ax.legend(loc = "upper right")
    plt.ylim(0,max_val)
    print("Done")


def Make_Average_array(folder_path, folder_name, time_interval):
    component_dir = folder_path+"/"+folder_name
    csvlist = natsorted(glob.glob(component_dir+"/*.csv"))
    average_val_array = np.zeros(len(csvlist), dtype = 'float64')
    time_array = np.zeros(len(csvlist), dtype = 'float64')
    for i in range(len(csvlist)):
        csv_array = np.loadtxt(csvlist[i], delimiter=',')
        average_val = np.mean(csv_array)
        average_val_array[i] = average_val
        time_array[i] = i*dt*time_interval
    return average_val_array, time_array


def make_plot_Division_ratio_non_cleave_normalize(folder_path, La, imta1, imta2, Lb, imtb1, imtb2, K1_sq, color_plot, power, time_interval):
    result1 = Make_Average_array(folder_path, La, time_interval)
    result2 = Make_Average_array(folder_path, imta1, time_interval)
    result3 = Make_Average_array(folder_path, imta2, time_interval)
    result4 = Make_Average_array(folder_path, Lb, time_interval)
    result5 = Make_Average_array(folder_path, imtb1, time_interval)
    result6 = Make_Average_array(folder_path, imtb2, time_interval)
    Psrate_a_array = (K1_sq)**power/((K1_sq)**power+(result1[0]+result2[0]+result3[0]+result4[0]+result5[0]+result6[0])**power)
    ini = (K1_sq)**power/((K1_sq)**power+1)
    Norm_Psrate_a_array = (Psrate_a_array - ini)/(1-ini)
    time_array = result1[1]
    plt.plot(time_array, Norm_Psrate_a_array, marker = "o", markersize=5, markeredgecolor = color_plot, linewidth=1, color=color_plot)
    plt.xlabel("normalized t (τ)")
    plt.ylabel("Division_ratio_normalize_non-cleave_Linker")
    plt.ylim(-0.1,1.1)
    plt.savefig(savedir+"/Division_ratio_plot_non-cleave_K"+str(K1_sq)+"_n"+str(power)+".png", dpi=300)
    plt.close('all')
    print("Done")

def make_plot_Linker_total(folder_path, La, Lb, color_plot, time_interval):
    result1 = Make_Average_array(folder_path, La, time_interval)
    result2 = Make_Average_array(folder_path, Lb, time_interval)
    time_array = result1[1]
    plt.plot(time_array, result1[0]+result2[0], marker = "o", markersize=5, markeredgecolor = color_plot, linewidth=1, color=color_plot)  # plot of total Linker conc.
    plt.xlabel("normalized t (τ)")
    plt.ylabel("Total Linker conc.")
    #plt.ylim(min_value,max_value)
    plt.savefig(savedir+"/Total_Lnker_conc.png", dpi=300)
    plt.close('all')
    print("Done")
    
def make_plot_delayed_Linker(folder_path, La, color_plot, time_interval):
    result1 = Make_Average_array(folder_path, La, time_interval)
    time_array = result1[1]
    plt.plot(time_array, result1[0], marker = "o", markersize=5, markeredgecolor = color_plot, linewidth=1, color=color_plot)  # plot of delayed Linker conc.
    plt.xlabel("normalized t (τ)")
    plt.ylabel("Delayed linker conc.")
    plt.ylim(-0.01,0.11)
    plt.savefig(savedir+"/Delayed_Lnker_conc_total.png", dpi=300)
    plt.close('all')
    print("Done")


########################## main function ###############################

def main():
    

    u_pf1 = np.zeros((L, L), dtype = 'float64')
    u_pf2 = np.zeros((L, L), dtype = 'float64')
    u_r1 = np.zeros((L, L), dtype = 'float64')
    u_r2 = np.zeros((L, L), dtype = 'float64')
    u_l = np.zeros((L, L), dtype = 'float64')
    u_f1 = np.zeros((L, L), dtype = 'float64')
    u_f2 = np.zeros((L, L), dtype = 'float64')
    u_imt1 = np.zeros((L, L), dtype = 'float64')
    u_imt2 = np.zeros((L, L), dtype = 'float64')
    u_cl1 = np.zeros((L, L), dtype = 'float64')
    u_cl2 = np.zeros((L, L), dtype = 'float64')

    u2_pf1 = np.zeros((L, L), dtype = 'float64')
    u2_pf2 = np.zeros((L, L), dtype = 'float64')
    u2_r1 = np.zeros((L, L), dtype = 'float64')
    u2_r2 = np.zeros((L, L), dtype = 'float64')
    u2_l = np.zeros((L, L), dtype = 'float64')
    u2_f1 = np.zeros((L, L), dtype = 'float64')
    u2_f2 = np.zeros((L, L), dtype = 'float64')
    u2_imt1 = np.zeros((L, L), dtype = 'float64')
    u2_imt2 = np.zeros((L, L), dtype = 'float64')
    u2_cl1 = np.zeros((L, L), dtype = 'float64')
    u2_cl2 = np.zeros((L, L), dtype = 'float64')

    v_pf1 = np.zeros((L, L), dtype = 'float64')
    v_pf2 = np.zeros((L, L), dtype = 'float64')
    v_r1 = np.zeros((L, L), dtype = 'float64')
    v_r2 = np.zeros((L, L), dtype = 'float64')
    v_l = np.zeros((L, L), dtype = 'float64')
    v_f1 = np.zeros((L, L), dtype = 'float64')
    v_f2 = np.zeros((L, L), dtype = 'float64')
    v_imt1 = np.zeros((L, L), dtype = 'float64')
    v_imt2 = np.zeros((L, L), dtype = 'float64')
    v_cl1 = np.zeros((L, L), dtype = 'float64')
    v_cl2 = np.zeros((L, L), dtype = 'float64')

    v2_pf1 = np.zeros((L, L), dtype = 'float64')
    v2_pf2 = np.zeros((L, L), dtype = 'float64')
    v2_r1 = np.zeros((L, L), dtype = 'float64')
    v2_r2 = np.zeros((L, L), dtype = 'float64')
    v2_l = np.zeros((L, L), dtype = 'float64')
    v2_f1 = np.zeros((L, L), dtype = 'float64')
    v2_f2 = np.zeros((L, L), dtype = 'float64')
    v2_imt1 = np.zeros((L, L), dtype = 'float64')
    v2_imt2 = np.zeros((L, L), dtype = 'float64')
    v2_cl1 = np.zeros((L, L), dtype = 'float64')
    v2_cl2 = np.zeros((L, L), dtype = 'float64')
    

    Initial_conc_Fuel(u_pf1,u_pf1_0)
    Initial_conc_Fuel(u_pf2,u_pf2_0)
    Initial_conc_Fuel(u_r1,u_r1_0)
    Initial_conc_Fuel(u_r2,u_r2_0)
    Initial_conc_Linker(u_l,u_l_0)
    Initial_conc_Fuel(u_f1,u_f1_0)
    Initial_conc_Fuel(u_f2,u_f2_0)

    Initial_conc_Fuel(v_pf1,v_pf1_0)
    Initial_conc_Fuel(v_pf2,v_pf2_0)
    Initial_conc_Fuel(v_r1,v_r1_0)
    Initial_conc_Fuel(v_r2,v_r2_0)
    Initial_conc_Linker(v_l,v_l_0)
    Initial_conc_Fuel(v_f1,v_f1_0)
    Initial_conc_Fuel(v_f2,v_f2_0)

    L_ini = u_l #Initial state of Linker.
    result = Calc_Linker_boundry_side(L_ini) #Getting Linker's edge and adjacent squares
    array_left, array_right, array_top, array_bottom = result[0], result[1], result[2], result[3]

    time_interval = 2000
	
    for i in range(220000):
        

        if i == 0:
            Linkers_shape(u_l, a_row, a_col) #Linker's initial state reading. Used for boundary conditions.

        if i % 2 == 0:
            Calc_next_La(u_pf1, u_pf2, u_r1, u_r2, u_l, u_f1, u_f2, u_imt1, u_imt2, u_cl1, u_cl2, u2_pf1, u2_pf2, u2_r1, u2_r2, u2_l, u2_f1, u2_f2, u2_imt1, u2_imt2, u2_cl1, u2_cl2, L_ini, array_left, array_right, array_top, array_bottom)
        else:
            Calc_next_La(u2_pf1, u2_pf2, u2_r1, u2_r2, u2_l, u2_f1, u2_f2, u2_imt1, u2_imt2, u2_cl1, u2_cl2, u_pf1, u_pf2, u_r1, u_r2, u_l, u_f1, u_f2, u_imt1, u_imt2, u_cl1, u_cl2, L_ini, array_left, array_right, array_top, array_bottom)
        
        if i % 2 == 0:            
            Calc_next_Lb(v_pf1, v_pf2, v_r1, v_r2, v_l, v_f1, v_f2, v_imt1, v_imt2, v_cl1, v_cl2, v2_pf1, v2_pf2, v2_r1, v2_r2, v2_l, v2_f1, v2_f2, v2_imt1, v2_imt2, v2_cl1, v2_cl2, L_ini, array_left, array_right, array_top, array_bottom)
        else:
            Calc_next_Lb(v2_pf1, v2_pf2, v2_r1, v2_r2, v2_l, v2_f1, v2_f2, v2_imt1, v2_imt2, v2_cl1, v2_cl2, v_pf1, v_pf2, v_r1, v_r2, v_l, v_f1, v_f2, v_imt1, v_imt2, v_cl1, v_cl2, L_ini, array_left, array_right, array_top, array_bottom)
        
        if i % time_interval == 0:
            save_csvfile(u_pf1,i,"pfa1")
            save_csvfile(u_pf2,i,"pfa2")
            save_csvfile(u_r1,i,"ra1")
            save_csvfile(u_r2,i,"ra2")
            save_csvfile(u_l,i,"La")
            save_csvfile(u_f1,i,"fa1")
            save_csvfile(u_f2,i,"fa2")
            save_csvfile(u_imt1,i,"imta1")
            save_csvfile(u_imt2,i,"imta2")
            save_csvfile(u_cl1,i,"cla1")
            save_csvfile(u_cl2,i,"cla2")

            save_csvfile(v_pf1,i,"pfb1")
            save_csvfile(v_pf2,i,"pfb2")
            save_csvfile(v_r1,i,"rb1")
            save_csvfile(v_r2,i,"rb2")
            save_csvfile(v_l,i,"Lb")
            save_csvfile(v_f1,i,"fb1")
            save_csvfile(v_f2,i,"fb2")
            save_csvfile(v_imt1,i,"imtb1")
            save_csvfile(v_imt2,i,"imtb2")
            save_csvfile(v_cl1,i,"clb1")
            save_csvfile(v_cl2,i,"clb2")
             
            print(str(i+1)+"_csv_step_Done")
    
    save_imgfile("pfa1")
    save_imgfile("pfa2")
    save_imgfile("ra1")
    save_imgfile("ra2")
    save_imgfile("La")
    save_imgfile("fa1")
    save_imgfile("fa2")
    save_imgfile("imta1")
    save_imgfile("imta2")
    save_imgfile("cla1")
    save_imgfile("cla2")
    save_imgfile("pfb1")
    save_imgfile("pfb2")
    save_imgfile("rb1")
    save_imgfile("rb2")
    save_imgfile("Lb")
    save_imgfile("fb1")
    save_imgfile("imtb1")
    save_imgfile("clb1")


    make_plot_Division_ratio_non_cleave_normalize(savedir, "La", "imta1", "imta2", "Lb", "imtb1", "imtb2", 0.05, "blue", 2, time_interval)
    make_plot_Linker_total(savedir, "La", "Lb", "red", time_interval)
    make_plot_delayed_Linker(savedir, "La", "red", time_interval)





       

if __name__ == "__main__":
    main()

#plt.imshow(main(), cmap="inferno")
#plt.savefig("output.png")